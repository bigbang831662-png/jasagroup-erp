Jasa Group ERP PWA V6

How to use:
1. Upload this folder to hosting OR open index.html for testing.
2. On Android Chrome, open the site.
3. Tap menu ⋮ > Add to Home screen / Install app.

Login:
Username: faisal
Password: 831662

Features:
- White/yellow theme
- Jasa Group white-background logo
- Invoice
- Deposit/payment
- Automatic Receipt
- Quotation
- Customers
- Print/PDF through browser print
- WhatsApp sharing
- Backup/Restore JSON

Important:
- Data is saved in the browser on that device.
- Use Backup regularly.
- For permanent multi-device storage, use the MySQL version.
